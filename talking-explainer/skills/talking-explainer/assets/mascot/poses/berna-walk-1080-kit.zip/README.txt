BERNA WALK: 1080-WIDE ANIMATION KIT

Master and all seven patch PNGs: 1080 x 2326. Source aspect ratio preserved to the nearest output pixel.
Place a patch over berna-walk-master-1080.png at x=0,y=0,100% opacity,same scale. Do not trim transparent margins. Select one mouth patch and optionally one eye patch.
Replacement patches include matching surrounding skin and feathered borders; they cover the old feature. Their remaining canvas is genuinely transparent.
Previews show every patch composited over the master. Comparison sheets and combined mouth/eye examples are included.
AI restoration improves detail but may introduce small differences from the tiny original. The seven patches preserve the new master outside local facial feature regions.
Method: built-in imagegen detail restoration and Berna feature assets, followed by local Pillow/OpenCV skin blending, positioning and compositing.
