BERNA THINK - RESTORED 1080-WIDE ANIMATION KIT

All master, patch and preview PNGs: 1080 x 2326.
Use this new master with these new patches. Place patches at x=0,y=0,100% opacity and same scale. Keep transparent margins. Select one mouth patch plus optionally one eye patch.
AI detail restoration improves clarity but can introduce small differences from the tiny original. The pose and overall appearance are preserved as closely as possible. Seven patches were composited locally against the restored master, preserving its pixels outside feature regions.
Source feature details and restoration: built-in imagegen. Prompt: restore crisp high-definition 3D detail while preserving Berna identity, thinking pose, original framing and transparent background; seven expressions are closed, slightly open, AH, O, EE, wink and blink.
