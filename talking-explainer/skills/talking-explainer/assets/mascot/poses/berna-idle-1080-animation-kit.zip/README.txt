BERNA IDLE — HD MASTER AND SEVEN REGISTERED FEATURE PATCHES

All master/patch/preview PNGs are 1080 x 2032 pixels. Original aspect ratio preserved to the nearest output pixel. The supplied 914 x 1720 image was already detailed, so it was enlarged and lightly sharpened without regenerating the character. Original alpha cutout retained.

Place one mouth patch over berna-idle-master-1080.png at x=0, y=0, 100% opacity and the same scale. Optionally add one eye patch. Do not crop or trim transparent canvas margins. The surrounding skin is part of the replacement patch; it covers the original feature and blends into unchanged master pixels.

Seven patches: closed MBP, slightly open, AH, rounded O, EE smile, viewer-right wink, both-eyes blink. The original is already mouth-closed, so the closed patch preserves its exact expression. Eyes preserve the original closed mouth.

Facial artwork was generated using built-in imagegen earlier in this conversation from the exact same Berna reference. The attached idle image is byte-identical to that closed-mouth master. Existing matching facial details were reused, positioned and composited locally using Pillow/OpenCV; no whole-character regeneration was performed for the variations.

Prompt set: change only the mouth to closed, slightly open, wide AH, rounded OH/OO or wide EE; preserve all unrelated facial/body details. Wink closes only viewer-right eye; blink closes both eyes; preserve original mouth. Genuine alpha transparency outside each local skin-blended feature replacement.

Validation: all canvases match; pixels outside patches are unchanged; mouth and eye layers compose in either order with zero difference. Previews show every patch and two combinations over the included master.
